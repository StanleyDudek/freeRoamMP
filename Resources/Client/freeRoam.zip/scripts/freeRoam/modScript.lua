load('freeRoam')
setExtensionUnloadMode('freeRoam', 'manual')
