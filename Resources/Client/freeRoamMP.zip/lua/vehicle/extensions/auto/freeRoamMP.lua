
local M = {}

local function onVehicleReady()
    print("---------------------------------------VEHICLE READY")
	obj:queueGameEngineLua("freeRoamMP.onVehicleReady(" .. obj:getID() .. ") ")
end

M.onVehicleReady    = onVehicleReady

return M
