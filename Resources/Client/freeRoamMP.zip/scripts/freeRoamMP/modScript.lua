load('freeRoamMP')
setExtensionUnloadMode('freeRoamMP', 'manual')
